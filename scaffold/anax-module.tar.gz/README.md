Anax MODULE_NAME
==================================

[![Latest Stable Version](https://poser.pugx.org/anax/MODULE_NAME/v/stable)](https://packagist.org/packages/anax/MODULE_NAME)
[![Join the chat at https://gitter.im/mosbth/anax](https://badges.gitter.im/Join%20Chat.svg)](https://gitter.im/canax?utm_source=badge&utm_medium=badge&utm_campaign=pr-badge&utm_content=badge)
[![Build Status](https://travis-ci.org/canax/MODULE_NAME.svg?branch=master)](https://travis-ci.org/canax/MODULE_NAME)
[![CircleCI](https://circleci.com/gh/canax/MODULE_NAME.svg?style=svg)](https://circleci.com/gh/canax/MODULE_NAME)
[![Build Status](https://scrutinizer-ci.com/g/canax/MODULE_NAME/badges/build.png?b=master)](https://scrutinizer-ci.com/g/canax/MODULE_NAME/build-status/master)
[![Scrutinizer Code Quality](https://scrutinizer-ci.com/g/canax/MODULE_NAME/badges/quality-score.png?b=master)](https://scrutinizer-ci.com/g/canax/MODULE_NAME/?branch=master)
[![Code Coverage](https://scrutinizer-ci.com/g/canax/MODULE_NAME/badges/coverage.png?b=master)](https://scrutinizer-ci.com/g/canax/MODULE_NAME/?branch=master)
[![SensioLabsInsight](https://insight.sensiolabs.com/projects/d831fd4c-b7c6-4ff0-9a83-102440af8929/mini.png)](https://insight.sensiolabs.com/projects/d831fd4c-b7c6-4ff0-9a83-102440af8929)

Anax MODULE_NAME module.



Usage
------------------

Short examples on how to use the module MODULE_NAME.



License
------------------

This software carries a MIT license.



```
 .  
..:  Copyright (c) YEAR AUTHOR_NAME (AUTHOR_EMAIL)
```
