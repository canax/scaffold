<?php
/**
 * Routes for controller.
 */
return [
    "routes" => [
        [
            "info" => "Controller for cLASSNAME.",
            "mount" => "cLASSNAME",
            "handler" => "\NAMESPACE\CLASSNAMEController",
        ],
    ]
];
