#!/usr/bin/env bash
#
# Postprocess scaffold
#
composer update
make cimage-update
