#!/usr/bin/env bash
#
# Postprocess scaffold
#
composer install
make cimage-update
