--
-- Creating a sample table.
--



--
-- Table CLASSNAME
--
DROP TABLE IF EXISTS CLASSNAME;
CREATE TABLE CLASSNAME (
    "id" INTEGER PRIMARY KEY NOT NULL,
    "column1" TEXT NOT NULL,
    "column2" TEXT NOT NULL
);
