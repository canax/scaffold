Lek
===========================

Här kan du länka till dina egna lek-sidor, inom eller utom din me-sida.

Du kan skriva egna routes i filen <code>src/route/app.php</code>, där finns några routehanterare som du kan utgå ifrån.

* [Hello world](lek/hello-world)
* [Hello world inuti me-sidan](lek/hello-world-wrap)

Du kan också lägga till vanlig PHP-kod i filer under katalogen htdocs, de kan du köra som vanliga enkla PHP-program.

* [Ett demo skript](demo/demo.php)
