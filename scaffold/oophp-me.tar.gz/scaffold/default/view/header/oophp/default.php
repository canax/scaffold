<?php

namespace Anax\View;

/**
 * Template file to render a view.
 */

// Show incoming variables and view helper functions
//echo showEnvironment(get_defined_vars(), get_defined_functions());

?>

<img class="header-logo" src="<?= asset("img/blad.jpg") ?>" alt="Logo">

HEADER <?= __FILE__ ?>
