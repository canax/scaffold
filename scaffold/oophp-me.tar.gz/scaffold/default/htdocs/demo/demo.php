<?php
echo __FILE__;

?><p>Just to show off how to write and execute a standalone PHP file outside the framework.</p>
