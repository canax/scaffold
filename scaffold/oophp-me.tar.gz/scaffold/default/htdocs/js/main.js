/**
 * To show off JS works and can be integrated.
 */
console.info("main.js ready and loaded.");
