/**
 * To show off JS works and can be integrated.
 */
(function() {
    "use strict";

    console.info("main.js ready and loaded.");
})();
