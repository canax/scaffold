<?php
/**
 * Config file for Anax MODULE_NAME.
 */
return [
    // empty
];
